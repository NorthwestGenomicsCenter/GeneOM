import{bn as l,a8 as o,bo as a}from"./D4pYgzvF.js";function c(){a({variableName:o("scrollbar.width").name})}function b(){l({variableName:o("scrollbar.width").name})}export{c as b,b as u};
