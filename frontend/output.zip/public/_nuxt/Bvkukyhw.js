import{bn as l,a8 as o,bo as a}from"./DntI3nKt.js";function c(){a({variableName:o("scrollbar.width").name})}function b(){l({variableName:o("scrollbar.width").name})}export{c as b,b as u};
