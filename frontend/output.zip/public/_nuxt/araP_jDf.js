import r from"./CcI-r5tx.js";import{B as n,P as o,c as s,o as l,V as i,b as d,m as a}from"./SiXFBImL.js";import"./Be1fzYNM.js";import"./D1IvDE4T.js";var p=({dt:e})=>`
.p-overlaybadge {
    position: relative;
}

.p-overlaybadge .p-badge {
    position: absolute;
    inset-block-start: 0;
    inset-inline-end: 0;
    transform: translate(50%, -50%);
    transform-origin: 100% 0;
    margin: 0;
    outline-width: ${e("overlaybadge.outline.width")};
    outline-style: solid;
    outline-color: ${e("overlaybadge.outline.color")};
}

.p-overlaybadge .p-badge:dir(rtl) {
    transform: translate(-50%, -50%);
}
`,v={root:"p-overlaybadge"},m=n.extend({name:"overlaybadge",style:p,classes:v}),c={name:"OverlayBadge",extends:r,style:m,provide:function(){return{$pcOverlayBadge:this,$parentInstance:this}}},g={name:"OverlayBadge",extends:c,inheritAttrs:!1,components:{Badge:r}};function y(e,u,b,B,$,f){var t=o("Badge");return l(),s("div",a({class:e.cx("root")},e.ptmi("root")),[i(e.$slots,"default"),d(t,a(e.$props,{pt:e.ptm("pcBadge")}),null,16,["pt"])],16)}g.render=y;export{g as default};
