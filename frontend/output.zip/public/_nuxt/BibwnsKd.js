import{bo as l,a9 as o,bp as a}from"./CKJ1u3YM.js";function c(){a({variableName:o("scrollbar.width").name})}function b(){l({variableName:o("scrollbar.width").name})}export{c as b,b as u};
