import{bP as l,bL as o,bQ as a}from"./N9tAakRj.js";function b(){a({variableName:o("scrollbar.width").name})}function c(){l({variableName:o("scrollbar.width").name})}export{b,c as u};
