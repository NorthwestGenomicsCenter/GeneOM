import{aa as a}from"./8RjB8N60.js";a.extend({name:"common"});
