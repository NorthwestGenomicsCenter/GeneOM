import{bO as l,bK as o,bP as a}from"./Nl_hHskv.js";function b(){a({variableName:o("scrollbar.width").name})}function c(){l({variableName:o("scrollbar.width").name})}export{b,c as u};
