import{bN as l,bJ as o,bO as a}from"./8RjB8N60.js";function b(){a({variableName:o("scrollbar.width").name})}function c(){l({variableName:o("scrollbar.width").name})}export{b,c as u};
