import{a5 as e}from"./N9tAakRj.js";e.extend({name:"common"});
