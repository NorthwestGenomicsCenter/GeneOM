import{a8 as e}from"./Nl_hHskv.js";e.extend({name:"common"});
